public class Roster {

	private Course course;

	private Student[] students;

	public List<Student> getStudents() {
		return null;
	}

	public boolean addStudent(Student student) {
		return false;
	}

	public int getStudentCount() {
		return 0;
	}

}
