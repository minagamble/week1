public class RecordedObservations extends Observation {

	private Student student;

	private Observation[] observations;

	public int photoObservation(String photoURL) {
		return 0;
	}

	public int photoObservation(String photoURL, double dLat, double dLong) {
		return 0;
	}

	public int writeObervation(String summ) {
		return 0;
	}

	public int writeObservation(String summ, String descr) {
		return 0;
	}

	public Student getStudent() {
		return null;
	}

	public List<Observation> getObservations() {
		return null;
	}

	public int getObservationCount() {
		return 0;
	}

	private int addObservation(Observation obs) {
		return 0;
	}

}
