public class Observation {

	private String id;

	private LocalDateTime datetime;

	public String getID() {
		return null;
	}

	public String read() {
		return null;
	}

	private String getDatetime() {
		return null;
	}

}
