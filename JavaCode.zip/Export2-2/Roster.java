import java.util.List;

public class Roster {

	Course course;

	private Student[] students;

	public Roster(Course course) {

	}

	public boolean addStudent(Student student) {
		return false;
	}

	public List<Student> getStudents() {
		return null;
	}

	public int getStudentCount() {
		return 0;
	}

}
