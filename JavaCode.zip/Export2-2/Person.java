public class Person {

	String name;

	String email;

	public String getName() {
		return null;
	}

	public String getEmail() {
		return null;
	}

	public String toString() {
		return null;
	}

}
