public class WrittenObservation extends Observation {

	private final String summary;

	private final String description;

	public String read() {
		return null;
	}

	public String getSummary() {
		return null;
	}

	public String getDescription() {
		return null;
	}

}
