public class SimpleID {

	private static final int counter;

	public static String generate() {
		return null;
	}

}
