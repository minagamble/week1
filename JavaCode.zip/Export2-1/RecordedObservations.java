import java.util.List;

public class RecordedObservations {

	private final Student student;

	private final List observations;

	public int photoObservation(String photoURL) {
		return 0;
	}

	public int photoObservation(String photoURL, Double dLat, Double dLong) {
		return 0;
	}

	public int writeObervation(String summ) {
		return 0;
	}

	public int writeObservation(String summ, String descr) {
		return 0;
	}

	public Student getStudent() {
		return null;
	}

	public List getObservations() {
		return null;
	}

	public int getObservationCount() {
		return 0;
	}

	private int addObservation(Observation obs) {
		return 0;
	}

}
