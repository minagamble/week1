import java.util.List;

public class FieldTrip {

	private final Course course;

	private final List observations;

	public int makeWrittenObservation(Student stu, String summ, String descr) {
		return 0;
	}

	public int makePhotoObservation(Student stu, String imgURL, Double dLat, Double dLong) {
		return 0;
	}

	public List getStudentNames() {
		return null;
	}

	public List getObservations() {
		return null;
	}

	public int getObservationCount() {
		return 0;
	}

	private RecordedObservations getRecordedObservations(Student stu) {
		return null;
	}

}
