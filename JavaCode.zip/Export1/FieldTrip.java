public class FieldTrip {

	private Course course;

	private RecordedObservations recordedObservations;

	private Course course;

	private RecordedObservations recordedObservations;

	private Course course;

	private RecordedObservations[] recordedObservations;

	public int makeWrittenObservation(Student stu, String summ, String descr) {
		return 0;
	}

	public int makePhotoObservation(Student stu, String imgURL, double dLat, double dLong) {
		return 0;
	}

	public List<String> getStudentNames() {
		return null;
	}

	public List<RecordedObservations> getObservations() {
		return null;
	}

	public int getObservationCount() {
		return 0;
	}

	private RecordedObservations getRecordedObservations(Student stu) {
		return null;
	}

}
