public class Observation {

	private String id;

	private LocalDateTime datetime;

	private RecordedObservations recordedObservations;

	public String getID() {
		return null;
	}

	public String read() {
		return null;
	}

	private String getDatetime() {
		return null;
	}

}
