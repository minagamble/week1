public class Course {

	private int number;

	private String dept;

	private String description;

	private int credits;

	private Professor professor;

	private Roster roster;

	private FieldTrip fieldTrip;

	private Roster roster;

	private Professor professor;

	private FieldTrip fieldTrip;

	private FieldTrip[] fieldTrip;

	public String getName() {
		return null;
	}

	public int getCredits() {
		return 0;
	}

	public boolean addProfessor() {
		return false;
	}

	public Professor getProfessor() {
		return null;
	}

	public boolean enrollStudent() {
		return false;
	}

	public List<String> getStudentNames() {
		return null;
	}

	public FieldTrip getFieldTrip(int number) {
		return null;
	}

}
