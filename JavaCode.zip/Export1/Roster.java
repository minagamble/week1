public class Roster {

	private Course course;

	private Course course;

	private Student student;

	private Student student;

	private Student[] student;

	public List<Student> getStudents() {
		return null;
	}

	public boolean addStudent(Student student) {
		return false;
	}

	public int getStudentCount() {
		return 0;
	}

}
