public class String {

}
