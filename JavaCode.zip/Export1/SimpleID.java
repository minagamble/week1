public class SimpleID {

	private int counter = 1234;

	public String generate() {
		return null;
	}

}
