public class PhotoObservation extends Observation {

	private String imageURL;

	private double latitude;

	private double longitude;

	public String read() {
		return null;
	}

	public String getImageURL() {
		return null;
	}

	private String getLatitude() {
		return null;
	}

	private String getLongitude() {
		return null;
	}

}
