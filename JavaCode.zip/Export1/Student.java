public class Student extends Person {

	private String major;

	private String favColor;

	private Roster roster;

	private Roster roster;

	private Roster roster;

	private RecordedObservations recordedObservations;

	public String getMajor() {
		return null;
	}

	public String getFavColor() {
		return null;
	}

	public String toString() {
		return null;
	}

}
